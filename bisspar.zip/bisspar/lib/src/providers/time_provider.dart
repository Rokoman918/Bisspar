import 'package:formvalidation/src/models/attendense_model.dart';
import 'package:http/http.dart' as http;



class TimeProvider{

final String _urlBase = 'https://restapibisspar20200301012821.azurewebsites.net/';

  String _response = ""; 

  Future<String>  setAttendance(AttendanceModel _attendence) async{
    final url ='$_urlBase/SetAttendance';
    final response = await _processResponse(url, _attendence);
    print( response );
    _response = response;   
    return response;
  }

  Future<String> _processResponse(String url, AttendanceModel att)async {

    Map<String, String> headers = {"Content-type": "application/json"};
    String jsonBody = attendanceToJson(att);
    final resp = await http.post(url, headers: headers, body: jsonBody);
    // check the status code for the result
    int statusCode = resp.statusCode;
    final String decodeData = resp.body;    
    if(decodeData == null) return "No hubo respuesta";
    print( decodeData );
    return  decodeData; 
  }


}