import 'package:flutter/material.dart';
import 'package:formvalidation/src/pages/manage_time/ui/widgets/historical_record.dart';


class HistoricalRecordList extends StatelessWidget{
  @override
  Widget build(BuildContext context) {

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        new HistoricalRecord("assets/Rodri.png", "Control Acceso Colciencias","Entrada 7:45", "Salida     10:45"),
        new HistoricalRecord("assets/Rodri.png",  "CCTV Hotel Dann","Entrada 10:46", "Salida     14:00"),
        new HistoricalRecord("assets/Rodri.png", "Oficina Principal", "Entrada 14:01", "Salida    - Sin Dato" )
      ],

    );
  }


}