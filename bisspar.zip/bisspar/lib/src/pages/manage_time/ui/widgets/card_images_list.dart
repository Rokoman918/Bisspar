import 'package:flutter/material.dart';
import 'package:formvalidation/src/models/project_model.dart';
import 'package:formvalidation/src/pages/manage_time/ui/widgets/description_project.dart';

import 'package:formvalidation/src/providers/project_provider.dart';
import  'card_images.dart';

class CardImageList extends StatelessWidget{

DescriptionProject despro = new DescriptionProject("", "");

final ProjectProvider  _projectProvider  = new ProjectProvider();
 
List<Project> listP = new List<Project>();

@override
  Widget build(BuildContext context) {    

    //TODO descomentar en caso de hacer funcionar el Streambuilder
    //ProjectProvider().getProjects(4017);
    return Container(
      height: 350.0, //Marca el alto de las cards de proyectos
      
      child: FutureBuilder(
          future:ProjectProvider().getProjects(4017),
          builder:(BuildContext context , AsyncSnapshot <List> snapshot )  {  

              if(snapshot.hasData){
                    return listViewProjects(buildCardImagesProject(snapshot.data));   
              }
              else{
                    return Center(child: CircularProgressIndicator());
              }
               
                         /*switch (snapshot.connectionState){
                           case ConnectionState.waiting:
                             return Center(child:CircularProgressIndicator());
                             
                           case ConnectionState.none:
                               return Center(child: CircularProgressIndicator());
                               
                           case ConnectionState.active:
                             return listViewProjects( buildCardImagesProject(snapshot.data));
                             
                           case ConnectionState.done:
                             return listViewProjects( buildCardImagesProject(snapshot.data));
                          
                         }
                          */
                     }        
                     
                     ) 
                 );
               
             }
           
           Widget  listViewProjects(List<CardImageWithFabIcon> projectCard)
           {
             return ListView(
                 padding: EdgeInsets.all(25.0),
                 scrollDirection: Axis.horizontal,
                 children: projectCard,
           
             );
           }
           

           //TODO de aqui podemos sacar el uso del Gift 
           Widget  _crearItem( BuildContext context , Project  proyecto){
           
             return Dismissible(
               key:UniqueKey(),
               background: Container(
                 color:Colors.deepPurpleAccent,
               ),
               onDismissed: (direcccion){
                //productProvider.borrarProducto(producto.id);
               },
               child: Card(
                 child: Column(
                   children: <Widget>[
                     (proyecto.imagenUrl == null)
                     ?Image(image: AssetImage('assets/no-image.png'))
                     :FadeInImage(
                       image: NetworkImage(proyecto.imagenUrl),
                       placeholder: AssetImage('assets/loading.gif'),
                       height: 180.0,
                       width: double.infinity ,
                       fit:BoxFit.cover,
                     ),
                      ListTile(
                 title: Text('${proyecto.nombre } - ${proyecto.descripcion}'),
                 subtitle: Text(proyecto.id.toString()),
                 onTap: () => Navigator.pushNamed(context, 'product', arguments: "")
               ),
                   ],
           
                 ),
               ),
           
             );
           }
           




List<CardImageWithFabIcon> buildCardImagesProject(List<Project> projectSnapShot){

List<CardImageWithFabIcon> projectsCard = List<CardImageWithFabIcon>();
double width= 240.0;
double height = 210.0;
double left =20.0;
double top = 80.0;
String namePro = "";
String desPro = "";

IconData iconData = Icons.favorite_border;


projectSnapShot.forEach((f){

projectsCard.add(CardImageWithFabIcon(
  height: height,
  width: width,
  pathImage: f.imagenUrl,
  left: left,
  top: top,

  nameproject: '${f.descripcion}\n${f.nombre}',
  onPressedFabIcon: (){

      _showProject( f.nombre, f.descripcion);
  },
  iconData: iconData,


));


});
return projectsCard;


}



_showProject(  String nameProject, String descriptionProject) {
 
despro.descriptionPrpject = descriptionProject;
despro.nameProject = nameProject;


//IconData() = !IconData(); 


//place.liked = !place.liked;
//setState(() {})
}

}