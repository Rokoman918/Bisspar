import 'dart:io';

import 'package:flutter/material.dart';
import 'package:formvalidation/src/models/attendense_model.dart';
import 'package:geolocator/geolocator.dart';
import 'package:formvalidation/src/pages/manage_time/ui/widgets/description_project.dart';
import 'package:formvalidation/src/pages/manage_time/ui/widgets/historical_record_list.dart';
import 'package:formvalidation/src/providers/product_provider.dart';
import 'package:formvalidation/src/providers/time_provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:formvalidation/src/utils/utils.dart' as utils;
import 'package:intl/intl.dart';
import 'header.dart';

class ManageTimes extends StatefulWidget {
  @override
  _ManageTimes createState() => _ManageTimes();
}

class _ManageTimes extends State<ManageTimes>   {

  String projectDescription ="Para registrar tiempo en cada proyecto debe seleccionar uno de la lista de proyectos disponibles";
  String projectName = 'Seleccione Proyecto';
  final formKey = GlobalKey<FormState>();
  final scafolKey = GlobalKey<ScaffoldState>();
  final productoProvider = new ProductProvider();
  final timeProvider = new TimeProvider();
  final double height_size = 100.0;
  final double width_size = 100.0;
  final width_texFormField = 150.0;
  final double borderRadius_circular = 10.0;
  static DateTime now = DateTime.now();

  String formattedDate = DateFormat('dd-MM-yyyy').format(now);
  AttendanceModel   attendenceModel = new AttendanceModel();
  bool _guardando = false;
  File foto;
  Position position;  
  List<Placemark> placemark;


  @override
  Widget build(BuildContext context) {
    return  Stack(
      children: <Widget>[
        ListView(
          children: <Widget>[
            DescriptionProject(projectName, projectDescription),
                  _createFieldsAndPhoto(),
                  _actualizarGPS(),
                  _crearBoton(),
                  _LabelHistory(),
                  _LabelDate(),
                  HistoricalRecordList(),
            //ReviewList()
          ],
        ),
             HeaderAppbar(),   
      ],
    );
  }



  
  Widget _createFieldsAndPhoto() {
    return Row(
      children: <Widget>[_form(), _showPhoto()],
    );
  }


  Widget _form (){
  return Container(
    padding: EdgeInsets.all(15.0),
    child: Form(
      key: formKey,
      child: _creteFields()
      ),

  );
}

  Widget _creteFields() {
    return Column(
      children: <Widget>[
        Container(
          width: width_texFormField,
          margin: EdgeInsets.only(top: 20.0, left: 20.0, right: 10.0),
          child: TextFormField(
            //initialValue: productModel.valor.toString(),
            keyboardType: TextInputType.numberWithOptions(decimal: false),
            decoration: InputDecoration(
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0)),
                hintText: 'Código',
                labelText: 'Código Interno'),
            onSaved: (value) => attendenceModel.idPersona = int.parse(value),
            validator: (value) {
              if (utils.isNumeric(value)) {
                return null;
              } else {
                return 'Ingrese Sólo Números';
              }
            },
          ),
        ),
        Container(
          width: width_texFormField,
          margin: EdgeInsets.only(top: 15.0, left: 20.0, right: 10.0),
          child: TextFormField(
              keyboardType: TextInputType.visiblePassword,
              //initialValue: productModel.nombre,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0)),
                  hintText: 'Pin',
                  labelText: 'Pin Secreto'),
              onSaved: (value) => attendenceModel.pin = value,
              validator: (value) {
                if (value.length < 2) {
                  return 'Ingrese su Pin secreto';
                } else {
                  return null;
                }
              }),
        )
      ],
    );
  }

  Widget _crearBoton() {
    return RaisedButton.icon(
     
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
      color: Colors.deepPurple,
      textColor: Colors.white,
      onPressed: (_guardando) ? null : _onSubmit,
      icon: Icon(Icons.access_time),
      label: Text('Registrar'),
    );
  }

  void _onSubmit() async {
    //Activamos la validacion de formulario 
   if (!formKey.currentState.validate()) return;
    //Activamos el onsave de los txtformfield dentro del formulario
   formKey.currentState.save();

    setState(() {
      _guardando = true;
    });

    if (foto != null) {
      //productModel.urlPhoto = await productoProvider.subirImagen(foto);
      //TODO  Activar la carga de la foto
      //attendenceModel.rutaFoto  = await timeProvider.subirImagen(foto);
    }

/*
    if (productModel.id == null) {
      productoProvider.crearProducto(productModel);
    } else {
      productoProvider.editarProducto(productModel);
    }
  */


  List<Placemark> Address = await getLocation();
  //TODO pintar la diección en la interface de usuario 
  attendenceModel.observacionRegistro="Desde el movil";
  
  //timeProvider.setAttendene(attendenceModel);

    mostrarSnackbar('Registro guardado');

    Navigator.pop(context);


        setState(() {
      _guardando = false;
    });

  }

  mostrarSnackbar(String mensaje) {
    final snackbar = SnackBar(
      content: Text(mensaje),
      duration: Duration(milliseconds: 1500),
    );
    scafolKey.currentState.showSnackBar(snackbar);
  }
 
Widget _actualizarGPS() {
    return SwitchListTile(
      value: false,
      title: Text('Geo Posición'),
      activeColor: Colors.deepPurple,
      onChanged: (value) => setState(()  {
        //Aqui hay que poner el llamado  para que lea el GPS
        getLocation();

      }),
    );
  }


Future <List<Placemark>>  getLocation() async{

    GeolocationStatus geolocationStatus  = await Geolocator().checkGeolocationPermissionStatus();
    
    if(geolocationStatus.value == true){
      //TODO Enviar mensaje de habilitar GPS
    }
    else{
      position = await Geolocator().getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      attendenceModel.longitud = position.longitude;
      attendenceModel.latitud = position.latitude;
      List<Placemark> placemark = await Geolocator().placemarkFromCoordinates(position.latitude, position.longitude);    
    }

    return placemark;
  }

  Widget _showPhoto() {

      if (foto != null) {
      return Material(        
              child: InkWell(
                onTap: () {
                  _tomarFoto();
                  setState(() {});
                  },
                child: Container(                  
                  child:  Image.file(
                            foto,
                            height: height_size,
                            fit: BoxFit.contain,
                          ),
                ),
              )
              ,
          );
      
      }

      return Material(
              child: InkWell(
                onTap: () {
                  _tomarFoto();
                  setState(() {});
                  },
                child: Container(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20.0),
                    child: Image.asset('assets/camera.png',
                        width: width_size, height: height_size),
                  ),),
              )
          );


       // return Image.asset('assets/camera.png', height: height_Size ,width: width_Size , );
    
    
 
  }

  _seleccionarFoto() async {
    _procesarImagen(ImageSource.gallery);
  }

  _tomarFoto() async {
    _procesarImagen(ImageSource.camera);
  }

  _procesarImagen(ImageSource origen) async {
    foto = await ImagePicker.pickImage(source: origen);

    if (foto != null) {
      attendenceModel.rutaFoto = null;
    }

    setState(() {});
  }



  Widget _LabelHistory() {
    return Container(
      margin: EdgeInsets.only(top: 25.0, left: 10.0, right: 10.0, bottom: 0.0),
      child: Text('Historico de\nMarcaciones Hoy\n',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontFamily: "Lato", fontSize: 18.0, fontWeight: FontWeight.w900)),
    );
  }

  Widget _LabelDate() {
    return Container(
       alignment: AlignmentDirectional.bottomCenter,
      child: Text('(${formattedDate.toString()})',
          textAlign: TextAlign.justify,
          style: TextStyle(
              fontFamily: "Lato", fontSize: 12.0, fontWeight: FontWeight.w900)),
    );
  }


 

}