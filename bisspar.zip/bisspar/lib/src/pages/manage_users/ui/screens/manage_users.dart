
import 'package:flutter/material.dart';

class ManageUsers extends  StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _ManageUsers();
  }

}

class _ManageUsers extends State<ManageUsers>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      color: Colors.blueGrey,
    );

  }

}