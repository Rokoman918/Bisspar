import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:formvalidation/src/models/product_model.dart';
import 'package:formvalidation/src/models/project_model.dart';
import 'package:formvalidation/src/pages/manage_time/ui/screens/header.dart';
import 'package:formvalidation/src/pages/manage_time/ui/widgets/description_project.dart';
import 'package:formvalidation/src/pages/manage_time/ui/widgets/historical_record_list.dart';

import 'package:formvalidation/src/providers/product_provider.dart';
import 'package:formvalidation/src/providers/project_provider.dart';

import 'package:formvalidation/src/utils/utils.dart' as utils;
import 'package:image_picker/image_picker.dart';


import 'manage_time/ui/screens/home_page_bisspar_time.dart';

class TimePage extends StatefulWidget {
  @override
  _TimePageState createState() => _TimePageState();
}

class _TimePageState extends State<TimePage> {
  final formKey = GlobalKey<FormState>();
  final scafolKey = GlobalKey<ScaffoldState>();
  final productoProvider = new ProductProvider();
  final double height_Size = 100.0;
  final double width_Size = 100.0;
  final width_TexFormField = 150.0;
  final double borderRadius_circular = 10.0;

  

  ProductModel productModel = new ProductModel();
  bool _guardando = false;
  File foto;

  @override
  Widget build(BuildContext context) {
    final ProductModel prodData = ModalRoute.of(context).settings.arguments;

    if (prodData != null) {
      productModel = prodData;
    }

    return Scaffold(
      key: scafolKey,
     /* appBar: AppBar(
        title: Text('Gestión del Tiempo',
        style: TextStyle(
        color: Colors.white,
        fontSize: 15.0,
        fontFamily: "Lato",
        fontWeight: FontWeight.bold)
        )
        ,
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.photo_size_select_actual),
            onPressed: _seleccionarFoto,
            
          ),
          IconButton(
            icon: Icon(Icons.camera_alt),
            onPressed: _tomarFoto,
          )
        ],
      ),*/
      body: Column(
        children: <Widget>[

           HeaderAppbar(),           
             DescriptionProject('Seleccione Proyecto','Para registrar tiempo en cada proyecto debe seleccionar uno de la lista de proyectos disponibles'),
             SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.all(15.0),
              child: Form(
                  key: formKey,
                  child: Column(                    
                    children: <Widget>[                     
                        _createFieldsAndPhoto(),
                        _crearDisponible(),
                        _crearBoton(),
                        //HistoricalRecordList(),
                    ],
                  )),
            ),
          ),
       
      
          
        ],
      ),
    
     );
  
  }

  Widget _createFieldsAndPhoto() {
    return Row(
      children: <Widget>[_creteFields(), _showPhoto()],
    );
  }

  Widget _creteFields() {
    return Column(
      children: <Widget>[
        Container(
          width: width_TexFormField,
          margin: EdgeInsets.only(top: 5.0, left: 10.0, right: 5.0),
          child: TextFormField(
            //initialValue: productModel.valor.toString(),
            keyboardType: TextInputType.numberWithOptions(decimal: false),
            decoration: InputDecoration(
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0)),
                hintText: 'Código',
                labelText: 'Código Interno'),
            onSaved: (value) => productModel.valor = double.parse(value),
            validator: (value) {
              if (utils.isNumeric(value)) {
                return null;
              } else {
                return 'Solo Numeros';
              }
            },
          ),
        ),
        Container(
          width: width_TexFormField,
          margin: EdgeInsets.only(top: 5.0, left: 10.0, right: 5.0),
          child: TextFormField(
              keyboardType: TextInputType.visiblePassword,
              //initialValue: productModel.nombre,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0)),
                  hintText: 'Pin',
                  labelText: 'Pin Secreto'),
              onSaved: (value) => productModel.nombre = value,
              validator: (value) {
                if (value.length < 2) {
                  return 'Ingrese su pin secreto';
                } else {
                  return null;
                }
              }),
        )
      ],
    );
  }

  Widget _crearBoton() {
    return RaisedButton.icon(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
      color: Colors.deepPurple,
      textColor: Colors.white,
      onPressed: (_guardando) ? null : _onSubmit,
      icon: Icon(Icons.save),
      label: Text('Guardar'),
    );
  }

  void _onSubmit() async {
    if (!formKey.currentState.validate()) return;

    formKey.currentState.save();

    setState(() {
      _guardando = true;
    });

    if (foto != null) {
      productModel.urlPhoto = await productoProvider.subirImagen(foto);
    }

    if (productModel.id == null) {
      productoProvider.crearProducto(productModel);
    } else {
      productoProvider.editarProducto(productModel);
    }
    mostrarSnackbar('Registro guardado');

    Navigator.pop(context);
  }

  mostrarSnackbar(String mensaje) {
    final snackbar = SnackBar(
      content: Text(mensaje),
      duration: Duration(milliseconds: 1500),
    );
    scafolKey.currentState.showSnackBar(snackbar);
  }
  Widget _crearDisponible() {
    return SwitchListTile(
      value: productModel.disponible,
      title: Text('Disponible'),
      activeColor: Colors.deepPurple,
      onChanged: (value) => setState(() {
        productModel.disponible = value;
      }),
    );
  }

  Widget _showPhoto() {
    if (productModel.urlPhoto != null) {
      return Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/camera.png")
             ,
             fit: BoxFit.contain
            ),
          borderRadius: BorderRadius.circular(borderRadius_circular),
        ),
        margin: EdgeInsets.only(top: 20.0, left: 5.0, right: 10.0, bottom: 15.0),
        child:InkWell(
              onTap: () {         
                _tomarFoto();
              }
          ),
        
         //FadeInImage(
          //image: NetworkImage(productModel.urlPhoto),
          //placeholder: AssetImage('assets/loading.gif'),
          //height: height_Size,
          //fit: BoxFit.contain,
        //),
      );
    } else {
      if (foto != null) {
      return Material(
              child: InkWell(
                onTap: () {
                  _tomarFoto();
                  setState(() {});
                  },
                child: Container(
                  child:  Image.file(
                            foto,
                            height: height_Size,
                            fit: BoxFit.contain,
                          ),
                ),
              )
          );
      
      
      
      
       /* return Container(
          decoration: BoxDecoration(
          image: DecorationImage(image: AssetImage("assets/camera.png")),
          borderRadius: BorderRadius.circular(borderRadius_circular),
        ),
        margin: EdgeInsets.only(top: 20.0, left: 5.0, right: 10.0, bottom: 15.0),
            child: Image.file(
            foto,
            height: height_Size,
            fit: BoxFit.contain,
          ),
        );*/
      }

      return Material(
              child: InkWell(
                onTap: () {
                  _tomarFoto();
                  setState(() {});
                  },
                child: Container(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20.0),
                    child: Image.asset('assets/camera.png',
                        width: width_Size, height: height_Size),
                  ),),
              )
          );


       // return Image.asset('assets/camera.png', height: height_Size ,width: width_Size , );
    
    
    }
  }

  _seleccionarFoto() async {
    _procesarImagen(ImageSource.gallery);
  }

  _tomarFoto() async {
    _procesarImagen(ImageSource.camera);
  }

  _procesarImagen(ImageSource origen) async {
    foto = await ImagePicker.pickImage(source: origen);

    if (foto != null) {
      productModel.urlPhoto = null;
    }

    setState(() {});
  }




}
