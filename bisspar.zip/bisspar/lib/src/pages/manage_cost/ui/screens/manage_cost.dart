import 'package:flutter/material.dart';

class ManageCost extends  StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _GestionCost();
  }

}

class _GestionCost extends State<ManageCost>{
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.greenAccent,
    );

  }

}