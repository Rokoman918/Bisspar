import 'package:flutter/material.dart';
import 'package:formvalidation/src/bloc/provider.dart';
import 'package:formvalidation/src/pages/home_page.dart';
import 'package:formvalidation/src/pages/manage_cost/ui/screens/manage_cost.dart';
import 'package:formvalidation/src/pages/manage_time/ui/screens/home_page_bisspar_time.dart';

import 'package:formvalidation/src/pages/login_page.dart';

import 'package:generic_bloc_provider/generic_bloc_provider.dart';

import 'bisspar_cupertino.dart';


void main() => runApp(MyApp());
 const PrimaryColor = const Color(0xFF584CD1);

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    
    return Provider(
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Material App',
        initialRoute: 'home',
        routes: {
          'login' : ( BuildContext context ) => LoginPage(),
          'home'  : ( BuildContext context ) =>  GestionProCupertino(),
         //'product':( BuildContext context ) => TimePage(),    
          'cost':( BuildContext context ) => ManageCost(),       
           },
        theme: ThemeData(
          primaryColor: PrimaryColor,
        ),
      ),
    
    );
     
  }
}